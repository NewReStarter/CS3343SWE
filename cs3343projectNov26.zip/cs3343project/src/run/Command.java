package run;

import Exception.ExOutOfBoard;

public interface Command {
	boolean execute();
}
